スクリプト名「AL_PropBox2」
制作者　ALINCO
Twitter(X):@ALINCO2020

[動作確認済み環境]
Windows 11 Mac
AfterEffects 2024 2025

[導入方法]
jsxファイルをScriptUI Panelsフォルダへ入れ、ウィンドウより実行。

[使用方法]
実行対象のプロパティを選択して実行。

プロパティを選択した状態で「↗」ボタンを押してmatchName（プロパティの本当の名前的なやつ）で対象を指定することも可能。選択された状態のプロパティがあったらそっちが優先される。

- min maxの横のRandomボタンで最小値〜最大値の範囲内で値をランダムに
- Random amountの横のRandomボタンで「現在の値 - Random amount」〜「現在の値 + Random amount」の範囲で値をランダムに
- プロパティを複数選択した状態でSequenceボタンをクリックで、現在の値からSequence amountの値分ずれていくように
  - Alt+クリックでマイナスの値に
  - Shift+クリックで全て同じだけずらす
- FixedボタンでFixed amountの値に（固定値）

下の2つのボタンはオマケ

Add keyframeボタンをクリックすると対象のプロパティにタイムライン上の現在の時間でキーフレームを追加する。  
Remove propertyボタンをクリックすると対象のプロパティが削除される（matchNameでの指定のみ対応）


バグを発見した方は「@ALINCO2020」へDMにてご報告頂けると助かります。