プラグイン名「RGBDelay」
制作者　ALINCO
twitter:@ALINCO2020

[動作確認済み環境]
Windows 10
AfterEffects 2022

[導入方法]
aexファイルを C: > Program Files > Adobe > Adobe After Effects バージョン > Support Files > Plug-ins フォルダへ。

[使用方法]
一番下に黒の平面レイヤーを置いて一番上の調整レイヤーに適用してください。黒の平面がなくても動きますがエッジがギザギザします。


個人で開発したプラグインなので不出来なところはご容赦ください。。。orz
バグを発見した方は「@ALINCO2020」へDMにてご報告頂けると助かります。