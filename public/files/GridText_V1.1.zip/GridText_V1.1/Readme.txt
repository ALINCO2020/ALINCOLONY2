スクリプト名「GridText」
制作者　ALINCO
twitter:@ALINCO2020

動作確認済み環境　AfterEffects 2022

[導入方法]
jsxファイルをScriptUI Panelsフォルダへ入れ、ウィンドウより実行。

[使用方法]
GG分解でバラバラにしてから使用してください。

バグを発見した方は「@ALINCO2020」へDMにてご報告頂けると助かります。