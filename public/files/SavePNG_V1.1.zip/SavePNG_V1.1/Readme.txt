スクリプト名「SavePNG」
制作者　ALINCO
twitter:@ALINCO2020

動作確認済み環境　AfterEffects 2022

[導入方法]
jsxbinファイルをScriptUI Panelsフォルダへ入れ、ウィンドウより実行。


バグを発見した方は「@ALINCO2020」へDMにてご報告頂けると助かります。