(function () {
  app.beginUndoGroup("shift to now");
  var comp = app.project.activeItem;
  var selectedLayers = comp.selectedLayers
  var inPoints = []
  for (var i = 0; i < selectedLayers.length; i++) {
    inPoints.push(selectedLayers[i].inPoint)
  }
  var tmpTime = 9999999
  for (var i = 0; i < inPoints.length; i++) {
    if (tmpTime > inPoints[i]) {
      tmpTime = inPoints[i]
    }
  }
  var diff = comp.time - tmpTime
  for (var i = 0; i < selectedLayers.length; i++) {
    var selectedLayer = selectedLayers[i]
    if (selectedLayer.startTime == selectedLayer.inPoint) {
      selectedLayer.startTime = diff + selectedLayer.inPoint
    } else {
      selectedLayer.startTime = diff + selectedLayer.startTime
    }
  }
  app.endUndoGroup();
})()