スクリプト名「Transform」
制作者　ALINCO
Twitter(X):@ALINCO2020

[動作確認済み環境]
Windows 10 Mac
AfterEffects 2022 2023 2024

[導入方法]
jsxファイルをScriptUI Panelsフォルダへ入れ、ウィンドウより実行。

・Ctrlクリックでキーフレーム上でも他のキーフレームの値を更新しなくなります。
・Alt+Sequenceクリックでマイナスの値になります。
・Shift+Sequenceクリックで全て同じだけずらします。


バグを発見した方は「@ALINCO2020」へDMにてご報告頂けると助かります。