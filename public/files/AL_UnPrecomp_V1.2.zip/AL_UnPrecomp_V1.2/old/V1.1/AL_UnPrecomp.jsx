﻿(function () {
  try {
    function shiftToNow(selectedLayers, baseTime) {
      var inPoints = []
      for (var i = 0; i < selectedLayers.length; i++) {
        inPoints.push(selectedLayers[i].inPoint)
      }
      var tmpTime = 9999999
      for (var i = 0; i < inPoints.length; i++) {
        if (tmpTime > inPoints[i]) {
          tmpTime = inPoints[i]
        }
      }
      var diff = baseTime - tmpTime
      for (var i = 0; i < selectedLayers.length; i++) {
        var selectedLayer = selectedLayers[i]
        if (selectedLayer.startTime == selectedLayer.inPoint) {
          selectedLayer.startTime = diff + selectedLayer.inPoint
        } else {
          selectedLayer.startTime = diff + selectedLayer.startTime
        }
      }
    }

    app.beginUndoGroup("Unprecomp");
    var comp = app.project.activeItem;
    var now = comp.time
    var selectedLayers = comp.selectedLayers
    for (var i = 0; i < selectedLayers.length; i++) {
      selectedLayers[i].selected = false
    }
    for (var i = 0; i < selectedLayers.length; i++) {
      var selectedLayer = selectedLayers[i]
      if (selectedLayer.source instanceof CompItem == false) {
        continue
      }
      var selectedComp = selectedLayer.source;
      selectedIndx = selectedLayer.index
      var centerX = selectedLayer.property("ADBE Transform Group").property("ADBE Position").value[0];
      var centerY = selectedLayer.property("ADBE Transform Group").property("ADBE Position").value[1];
      var scale1 = selectedLayer.property("ADBE Transform Group").property("ADBE Scale").value[0];
      var scale2 = selectedLayer.property("ADBE Transform Group").property("ADBE Scale").value[1];
      var rotate = selectedLayer.property("ADBE Transform Group").property("ADBE Rotate Z").value;

      var tempPlane = selectedComp.layers.addNull();
      tempPlane.name = "Unprecomp_temp";
      var movingLayers = []

      // ペアレント設定・マット設定を取得
      var parents = []
      var mattes = []
      var matteTypes = []
      for (var j = 0; j < selectedComp.numLayers; j++) {
        if (selectedComp.layer(j + 1).name != 'Unprecomp_temp') {
          parents.push(selectedComp.layer(j + 1).parent)
          selectedComp.layer(j + 1).parent = null
          mattes.push(selectedComp.layer(j + 1).trackMatteLayer)
          matteTypes.push(selectedComp.layer(j + 1).trackMatteType)
        }
      }

      // copyToCompでコピー
      for (var j = selectedComp.numLayers; j >= 1; j--) {
        var tmpLayer = selectedComp.layer(j)
        tmpLayer.copyToComp(comp);
      }
      for (var j = 0; j < selectedComp.numLayers; j++) {
        if (comp.layer(j + 1).name != 'Unprecomp_temp') {
          comp.layer(j + 1).parent = comp.layer("Unprecomp_temp")
          movingLayers.push(comp.layer(j + 1))
        }
      }
      comp.layer("Unprecomp_temp").property("ADBE Transform Group").property("ADBE Position").setValue([centerX, centerY]);
      comp.layer("Unprecomp_temp").property("ADBE Transform Group").property("ADBE Scale").setValue([scale1, scale2]);
      comp.layer("Unprecomp_temp").property("ADBE Transform Group").property("ADBE Rotate Z").setValue(rotate);
      selectedComp.layer("Unprecomp_temp").remove()
      comp.layer("Unprecomp_temp").remove();

      // ペアレント設定・マット設定を適用
      for (var j = 0; j < movingLayers.length; j++) {
        if (parents[j] != null) {
          movingLayers[j].parent = comp.layer(parents[j].index)
        }
        if (mattes[j] != null) {
          movingLayers[j].setTrackMatte(comp.layer(mattes[j].index), matteTypes[j])
        }
      }

      // 選択したレイヤーの上に移動させる
      for (var j = 0; j < movingLayers.length; j++) {
        movingLayers[j].moveBefore(selectedLayer)
      }

      // 解除したコピー元コンポのペアレント設定をもとに戻す
      for (var j = 0; j < selectedComp.numLayers; j++) {
        if (parents[j] != null) {
          selectedComp.layer(j + 1).parent = parents[j]
        }
      }

      selectedLayer.enabled = false
      selectedLayer.shy = true

      shiftToNow(movingLayers, selectedLayer.inPoint)
    }

    comp.time = now
  } catch (e) {
    alert(e.message + e.line)
  }
  app.endUndoGroup();
})()