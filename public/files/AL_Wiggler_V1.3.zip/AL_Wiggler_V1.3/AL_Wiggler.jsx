(function () {
  /**
* 特定のプロパティを返す
* @param {*} rootObj レイヤーでもコンテンツでもOK
* @param {*} nestingLevel 0でOK
* @param {*} matchName 探したいプロパティのmatchName
* @returns 
*/
  function getProp(rootObj, nestingLevel, matchName) {
    var propTo = [];
    dumpPropTree(rootObj, nestingLevel, matchName);
    function dumpPropTree(rootObj, nestingLevel, matchName) {
      var countProps = rootObj.numProperties;
      for (var propIndex = 1; propIndex <= countProps; propIndex++) {
        var prop = rootObj.property(propIndex);
        if (prop.matchName == matchName) {
          propTo.push(prop)
        } else {
          dumpPropTree(prop, nestingLevel + 1, matchName);
        }
        if (propIndex == countProps) return;
      }
    }
    return propTo;
  }

  app.beginUndoGroup("AL_Wiggler");
  try {
    var ffxFile = File((new File($.fileName)).parent.toString() + "/AL_Wiggler/AL_Wiggler.ffx");
    var comp = app.project.activeItem
    var selectedLayers = comp.selectedLayers
    var selectedPropertiesDict = []
    var selectedPropertiesDictName = []
    // 選択されたプロパティを先に取得（ffxを適用すると選択状態が解除されるため）
    for (var i = 0; i < selectedLayers.length; i++) {
      var selectedLayer = selectedLayers[i]
      var selectedProperties = selectedLayer.selectedProperties
      var selectedPropertiesList = []
      var selectedPropertiesListName = []
      for (var j = 0; j < selectedProperties.length; j++) {
        var selectedProperty = selectedProperties[j]
        if (!selectedProperty.canSetExpression) continue;
        selectedPropertiesList.push(selectedProperty)
        selectedPropertiesListName.push(selectedProperty.name)
      }
      selectedPropertiesDict.push(selectedPropertiesList)
      selectedPropertiesDictName.push(selectedPropertiesListName)
    }
    // エクスプレッションを追加
    for (var i = 0; i < selectedLayers.length; i++) {
      var selectedLayer = selectedLayers[i]
      for (var j = 0; j < selectedPropertiesDict[i].length; j++) {
        var selectedProperty = selectedPropertiesDict[i][j]
        selectedProperty.expression = "var e = effect('ALW_" + selectedProperty.name + "');\nseedRandom(e(1));\nposterizeTime(e(4));\nwiggle(e(2), e(3));"
      }
    }
    // エフェクトを追加
    for (var i = 0; i < selectedLayers.length; i++) {
      var selectedLayer = selectedLayers[i]
      for (var j = 0; j < selectedPropertiesDict[i].length; j++) {
        if (i == 0 && j == 0) {
          selectedLayer.applyPreset(ffxFile);
        }
      }
    }
    // エフェクト名を変更
    for (var i = 0; i < selectedLayers.length; i++) {
      var selectedLayer = selectedLayers[i]
      var ffxEffects = getProp(selectedLayer.effect, 0, 'Pseudo/AL_Wiggler')
      ffxEffects.reverse()
      for (var j = 0; j < selectedPropertiesDict[i].length; j++) {
        var ffxEffect = ffxEffects[j]
        ffxEffect.name = 'ALW_' + selectedPropertiesDictName[i][j]
        ffxEffect.property(4).setValue(comp.frameRate)
      }
    }
  } catch (e) {
    alert(e.message + e.line)
  }
  app.endUndoGroup();
})()